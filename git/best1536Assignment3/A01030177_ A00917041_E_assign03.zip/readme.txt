Khide Hoskins, A01030177, Set E, kmosshoskins@my.bcit.ca
Brett Seguin, A00917041, Set E, bseguin@my.bcit.ca

COMPLETED:

- Everything

NOT COMPLETED:

MAJOR CHALLENGES:

AZURE: http://best1536assignment3.azurewebsites.net/